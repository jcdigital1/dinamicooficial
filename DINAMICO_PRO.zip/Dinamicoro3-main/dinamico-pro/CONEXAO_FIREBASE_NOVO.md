# Conexão Firebase definitivo — DINÂMICO PRO

Projeto selecionado: `dinamicopro-2dd62`.

O código original do aplicativo (telas, PDFs, modelos, QR Codes e rotas) foi mantido **sem alterações**. A conexão já é implementada via variáveis de ambiente em `src/lib/firebase.ts` e `server/firebase.ts`. Este pacote atualizou somente a documentação e incluiu `.env.example` com o ID do novo projeto.

## Para concluir na Vercel

1. Importar o repositório e configurar **Root Directory = `dinamico-pro`**.
2. Nas configurações do projeto → **Environment Variables**, cadastrar os campos do arquivo `.env.example`, substituindo as duas variáveis incompletas pelos valores completos do Firebase Console → Configurações do projeto → Seus apps → App da Web. Para segurança, não publicar o JSON administrativo no GitHub.
3. Criar a credencial da conta de serviço no Firebase Console → Configurações do projeto → Contas de serviço, e cadastrar seu conteúdo **somente** como `FIREBASE_SERVICE_ACCOUNT` nas variáveis privadas da Vercel.
4. Publicar as regras `firestore.rules` e os índices `firestore.indexes.json` deste projeto no Firestore novo; o banco em modo produção bloqueia acesso até isso ocorrer.
5. Autorizar o domínio definitivo em Authentication → Configurações → Domínios autorizados.
6. Testar login, aprovação, lote, QR Code, redirecionamento e geração PDF antes de trocar domínio ou imprimir plaquinhas.

**Atenção:** este pacote não foi implantado nem conectado ao Firebase na nuvem, pois faltam os valores completos da configuração Web e a credencial privada do servidor. Não há migração de registros do banco antigo; use scripts de exportação/importação originais apenas se houver dados que precisem ser preservados. Não crie QR Codes impressos antes de definir domínio definitivo.
